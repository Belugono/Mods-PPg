using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Events;

namespace mix
{
    public class mix
	{
        public static void Main()
        {
			ModAPI.Register(
				new Modification()
				{
					OriginalItem = ModAPI.FindSpawnable("Human"),
					NameOverride = "Pumpkin.",
					DescriptionOverride = " ",
					CategoryOverride = ModAPI.FindCategory("Entities"),
					ThumbnailOverride = ModAPI.LoadSprite("pumpkin_view.png"),
					AfterSpawn = (Instance) =>
					{
						var skin = ModAPI.LoadTexture("pumpkin.png");
						var flesh = ModAPI.LoadTexture("flesh_layout_1.png");
						var bone = ModAPI.LoadTexture("bone_layout_1.png");
						var person = Instance.GetComponent<PersonBehaviour>();
						person.SetBodyTextures(skin, flesh, bone, 1);
						person.SetBruiseColor(86, 62, 130);
						person.SetSecondBruiseColor(154, 0, 7);
						person.SetThirdBruiseColor(207, 206, 120);
						person.SetRottenColour(202, 199, 104);
						person.SetBloodColour(108, 0, 64);

		}
	}
			);
		}
	}
}
